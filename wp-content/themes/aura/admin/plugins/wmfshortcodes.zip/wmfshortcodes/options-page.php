<?php
function wmf_add_options_page() {
		add_options_page(__('WMF Shortcodes','wmft2d'), __('WMF Shortcodes','wmft2d'), 'manage_options', __FILE__, 'wmf_settings_form');
	}

	function wmf_add_defaults() {
			$arr = array(	
				"consumer_key"			=> "",
				"consumer_secret"			=> "",
				"access_token_key"			=> "",
				"access_token_secret"			=> ""
			);
			update_option( 'wmf_options', $arr );
	}

	function wmf_init(){
	
		register_setting( 'wmf_plugin_options', 'wmf_options' );

	}


	function wmf_settings_form(){
	?>
	<div class="wrap">
		<div class="icon32" id="icon-options-general"><br></div>
		<?php _e('<h2>WMF Shortcodes Options</h2>','wmft2d');?>
		<form method="post" action="options.php">
        
			<?php 
			settings_fields('wmf_plugin_options');  
			$options = get_option('wmf_options');  
			?>
			<table class="form-table">
			    <tr><?php _e('<h3>Twitter Settings</h3>','wmft2d');?></tr>
				<tr><?php _e('<p>New twitter API required keys & API codes below. Please read help documentation before fill this fields.</p>','wmft2d');?></tr>
				
                <tr valign="top" style="border-top:#dddddd 1px solid;">
					<th scope="row"><?php echo _e('Consumer Key','wmft2d');?></th>
					<td>
						<label><input name="wmf_options[consumer_key]" type="text" value="<?php if (isset($options['consumer_key'])) { echo $options['consumer_key']; } ?>"  /> </label><br /><span style="color:#666666;margin-left:2px;"><?php echo _e('Please enter Consumer Key','wmft2d');?></span>
					</td>
				</tr>
                
                <tr valign="top" style="border-top:#dddddd 1px solid;">
					<th scope="row"><?php _e('Consumer Secret','wmft2d');?></th>
					<td>
						<label><input name="wmf_options[consumer_secret]" type="text" value="<?php if (isset($options['consumer_secret'])) { echo $options['consumer_secret']; } ?>"  /> </label><br /><span style="color:#666666;margin-left:2px;"><?php _e('Please enter Consumer Secret','wmft2d');?></span>
					</td>
				</tr>
                
                <tr valign="top" style="border-top:#dddddd 1px solid;">
					<th scope="row"><?php _e('Access Token Key','wmft2d');?></th>
					<td>
						<label><input name="wmf_options[access_token_key]" type="text" value="<?php if (isset($options['access_token_key'])) { echo $options['access_token_key']; } ?>"  /> </label><br /><span style="color:#666666;margin-left:2px;"><?php _e('Please enter Access Token Key','wmft2d');?></span>
					</td>
				</tr>
                
                <tr valign="top" style="border-top:#dddddd 1px solid;">
					<th scope="row"><?php _e('Access Token Secret','wmft2d');?></th>
					<td>
						<label><input name="wmf_options[access_token_secret]" type="text" value="<?php if (isset($options['access_token_secret'])) { echo $options['access_token_secret']; } ?>"  /> </label><br /><span style="color:#666666;margin-left:2px;"><?php _e('Please enter Access Token Secret','wmft2d');?></span>
					</td>
				</tr>
                
                
			</table>
			<p class="submit">
			<input type="submit" class="button-primary" value="<?php _e('Save Changes','wmft2d') ?>" />
			</p>
		</form>


	</div>
	<?php	
	}

add_action('admin_menu', 'wmf_add_options_page');
register_activation_hook(__FILE__, 'wmf_add_defaults');
add_action('admin_init', 'wmf_init');
?>