<?
$absolute_path = __FILE__;
$path_to_file = explode( 'wp-content', $absolute_path );
$path_to_wp = $path_to_file[0];
require_once( $path_to_wp.'/wp-load.php' );
$options = get_option('wmf_options'); 

if(isset($options['consumer_key']) == NULL){$CONSUMER_KEY = "";}else{$CONSUMER_KEY = $options['consumer_key'];}
if(isset($options['consumer_secret']) == NULL){$CONSUMER_SECRET = "";}else{$CONSUMER_SECRET = $options['consumer_secret'];}
if(isset($options['access_token_key']) == NULL){$ACCESS_TOKEN = "";}else{$ACCESS_TOKEN = $options['access_token_key'];}
if(isset($options['access_token_secret']) == NULL){$ACCESS_TOKEN_SECRET = "";}else{$ACCESS_TOKEN_SECRET = $options['access_token_secret'];}

//We use already made Twitter OAuth library
//https://github.com/mynetx/codebird-php

require_once 'codebird.php';

if($CONSUMER_KEY != ''){
//Get authenticated
Codebird::setConsumerKey($CONSUMER_KEY, $CONSUMER_SECRET);
$cb = Codebird::getInstance();
$cb->setToken($ACCESS_TOKEN, $ACCESS_TOKEN_SECRET);


//retrieve posts
$q = $_POST['q'];
$count = $_POST['count'];
$api = $_POST['api'];

//https://dev.twitter.com/docs/api/1.1/get/statuses/user_timeline
//https://dev.twitter.com/docs/api/1.1/get/search/tweets
$params = array(
	'screen_name' => $q,
	'q' => $q,
	'count' => $count
);

//Make the REST call
$data123 = (array) $cb->$api($params);

//Output result in JSON, getting it ready for jQuery to process
echo json_encode($data123);
}
?>