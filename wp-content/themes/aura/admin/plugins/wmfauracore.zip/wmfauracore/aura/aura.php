<?php

//Define directories. auraplgt2d
define("WEAURA_THEME_URL", plugin_dir_url( __FILE__ ));
define("WEAURA_PLUGIN_CSS_URL",WEAURA_THEME_URL."css/");
define("WEAURA_PLUGIN_JS_URL",WEAURA_THEME_URL."js/");
define("WEAURA_PLUGIN_IMAGE_URL",WEAURA_THEME_URL."images/");

	
//Enque Styles & Scripts.
add_action( 'admin_enqueue_scripts', 'aura_admin_scripts' );
function aura_admin_scripts($hook){
	if( 'nav-menus.php' == $hook || 'settings_page_wmfauracore/options-page' == $hook){
		wp_enqueue_script('wp-color-picker');
		wp_enqueue_script('jquery');
		wp_enqueue_script('jquery-ui-core');
		wp_enqueue_script('jquery-ui-widget');
		wp_enqueue_script('jquery-ui-mouse');
		wp_enqueue_media();
		
		wp_register_script('select2-for-aura-scripts', WEAURA_PLUGIN_JS_URL . 'select2.min.js', array('jquery'), '1.0.0',false); 
        wp_enqueue_script('select2-for-aura-scripts'); 
		
    	wp_enqueue_style( 'wp-color-picker' );				
		wp_register_style('admin-ui-for-aura', WEAURA_PLUGIN_CSS_URL . 'redmond/jquery-ui-1.10.4.custom.min.css', array(), '1.10.4', 'all');
		wp_register_style('admin-styles-for-aura', WEAURA_PLUGIN_CSS_URL . 'admin-styles.css', array(), '1.0', 'all');
   		wp_register_style('admin-select2-for-aura', WEAURA_PLUGIN_CSS_URL . 'select2.css', array(), '1.0', 'all');
		wp_register_style('admin-fontawesome-for-aura', WEAURA_PLUGIN_CSS_URL . 'font-awesome.min.css', array(), '1.0', 'all');
		
		wp_enqueue_style('admin-ui-for-aura'); 
		wp_enqueue_style('admin-styles-for-aura'); 
		wp_enqueue_style('admin-select2-for-aura'); 
		wp_enqueue_style('admin-fontawesome-for-aura'); 
	}
}


include 'options-menu.php';

global $webbumobile_option;

$general_themeswitchermode = $webbumobile_option['general_themeswitchermode'];
		
if( $general_themeswitchermode != '0' ){

	// Register Point Menus
	function register_aura_menu_plgmode()
	{
		register_nav_menus(array( 
			'aura-main-menu' => __('Aura Mobile Main Menu', 'aurat2d'),
		));
	}
	add_action('init', 'register_aura_menu_plgmode');
	
}
?>