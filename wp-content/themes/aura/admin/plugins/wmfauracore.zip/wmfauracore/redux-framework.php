<?php
/**
 *
 * Plugin Name:     Webbu Aura Mobile Theme Core Elements
 * Plugin URI:      http://themeforest.net/user/Webbu
 * Description:     This plugin included with Aura Theme Options Panel & Menu area modifications. You need to activate this plugin for run Aura Theme.
 * Author:          Webbu
 * Author URI:      http://themeforest.net/user/Webbu
 * Version:         1.0.1
 *
 */

/**************************************************************************
*
* Below setting belong to translation system.
*
**************************************************************************/
function auramobile_lang_init() {
  load_plugin_textdomain( 'auraplgt2d', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}
add_action('plugins_loaded', 'auramobile_lang_init');


/**************************************************************************
*
* Below setting belong to control system.
*
**************************************************************************/

// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) {
    die;
}

// Require the main plugin class
require_once( plugin_dir_path( __FILE__ ) . 'class.redux-plugin.php' );
require_once( plugin_dir_path( __FILE__ ) . 'ReduxFramework.config.php' );
require_once( plugin_dir_path( __FILE__ ) . 'aura/aura.php' );

// Register hooks that are fired when the plugin is activated and deactivated, respectively.
register_activation_hook( __FILE__, array( 'ReduxFrameworkPlugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'ReduxFrameworkPlugin', 'deactivate' ) );


// Get plugin instance
//add_action( 'plugins_loaded', array( 'ReduxFrameworkPlugin', 'instance' ) );

// The above line prevents ReduxFramework from instancing until all plugins have loaded.
// While this does not matter for themes, any plugin using Redux will not load properly.
// Waiting until all plugsin have been loaded prevents the ReduxFramework class from 
// being created, and fails the !class_exists('ReduxFramework') check in the sample_config.php, 
// and thus prevents any plugin using Redux from loading their config file.
ReduxFrameworkPlugin::instance();

// Include aura core options.
require_once( plugin_dir_path( __FILE__ ) . 'aura/aura.php' );

//Auto updater - Source: http://w-shadow.com/blog/2010/09/02/automatic-updates-for-any-plugin/
include 'plugin-updates/plugin-update-checker.php';
$ExampleUpdateChecker = new PluginUpdateChecker(
	'http://www.webbudesign.com/plugins/wmfauracore/info.json',
	__FILE__, 'wmfauracore'
);


//Here's how you can add query arguments to the URL.
function addSecretKeyAuraCore($query){
	$query['secret'] = 'foo';
	return $query;
}
$ExampleUpdateChecker->addQueryArgFilter('addSecretKeyAuraCore');