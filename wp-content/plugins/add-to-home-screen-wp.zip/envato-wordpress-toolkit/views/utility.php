<h3 class="page-title">Utility</h3>
<ul>
    <li><strong>Backup</strong> all records by exporting them - <a class="actionbtn" href="<?php echo site_url();?>/wp-admin/admin.php?page=cwd-management&export=true">Export</a></li>
    <li><strong>Import</strong> CSV of records - <a class="actionbtn" href="<?php echo site_url();?>/wp-admin/admin.php?page=cwd-management&view=import">import</a></li>
</ul>
<br>
<br>
<hr>
<br>
<a class="actionbtn" href="<?php echo site_url();?>/wp-admin/admin.php?page=cwd-management">Dashboard</a>