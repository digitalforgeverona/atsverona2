<link rel="stylesheet" type="text/css" href="<?php echo plugins_url('simple-custom-website-data/css/styles.css')?>">
<div class="wrap cwd-wrapper">
    <p class="plugin-info">Version 1.4.1 | Visit the <a href="http://dev.dannyweeks.com/cwd/index.php">Custom Website Data</a> website</p>
    <h2>Custom Website Data </h2>