<?php
define('DB_HOST_1','localhost');
define('DB_USER_1', 'root');
define('DB_PASSWORD_1','');
define('DB_DATABASE_1','steel');
define('DB_TABLE_1','MARE_Match');
define('DB_TABLE_2','e107_MARE_Liv_Gara');
define('DB_TABLE_3','e107_MARE_Tipo_Gara');
define('DB_TABLE_Squadre','e107_MARE_Squadre');
define('DB_TABLE_Tiratori','e107_MARE_Tiratori');
define('DB_TABLE_Categorie','e107_MARE_Categorie');
define('DB_TABLE_Classi','e107_MARE_Classi');
define('DB_TABLE_Divisioni','e107_MARE_Divisioni_Steel');
define('DB_TABLE_Pf','e107_MARE_Pf');
define('DB_TABLE_Iscrizioni','e107_MARE_Iscrizioni');
define('DB_TABLE_FascieTiratori','e107_MARE_FascieTiratori');
define('DB_TABLE_OnLine','e107_online');
?>

