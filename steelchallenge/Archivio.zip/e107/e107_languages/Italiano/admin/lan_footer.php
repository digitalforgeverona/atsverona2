<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_footer.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/11/24 16:29:02 $
|     $Author: streaky $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Sito");
define("FOOTLAN_2", "Amministratore");
define("FOOTLAN_3", "Versione");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Tema");
define("FOOTLAN_6", "di");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Data Installazione");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "Versione PHP");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Informazioni Sito");
define("FOOTLAN_14", "Mostra documenti");
define("FOOTLAN_15", "Documentazione");
define("FOOTLAN_16", "Database");
define("FOOTLAN_17", "Charset");
define("FOOTLAN_18", "Tema del Sito");

?>
