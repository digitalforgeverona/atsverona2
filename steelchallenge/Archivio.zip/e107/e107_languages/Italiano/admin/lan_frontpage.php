<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_frontpage.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/02 06:14:20 $
|     $Author: sweetas $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("FRTLAN_1", "Impostazioni Pagina Principale aggiornate.");
define("FRTLAN_2", "Mostra");
define("FRTLAN_6", "Links");
// define("FRTLAN_7", "Pagina dei Contenuti");
define("FRTLAN_12", "Aggiorna impostazioni Pagina Principale");
define("FRTLAN_13", "Impostazioni Pagina Principale");
define("FRTLAN_15", "Altro (inserisci url):");
define("FRTLAN_16", "errore: nessuna Categoria principale selezionata");
define("FRTLAN_17", "errore: nessuna Sottocategoria selezionata");
define("FRTLAN_18", "errore: nessun Articolo selezionato");
define("FRTLAN_19", "contenuto Categoria principale ");
define("FRTLAN_20", "contenuto categoria");
define("FRTLAN_21", "contenuto articolo");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");
define("FRTLAN_26", "tutti gli utenti");
define("FRTLAN_27", "Ospiti");
define("FRTLAN_28", "Utenti Registrati");
define("FRTLAN_29", "Amministratori");
define("FRTLAN_31", "tutti gli utenti");
define("FRTLAN_32", "Gruppo Utente");
define("FRTLAN_33", "Impostazioni attuali");
define("FRTLAN_34", "Pagina");
?>