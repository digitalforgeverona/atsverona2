<?php
//     Italian Translation:
//           e107 Italian Team http://www.e107it.org
//           con la collaborazione di Stefano Vecchi


$text = "Puoi separare i tuoi collegamenti tra differenti categorie semplificando la navigazione nella pagina dei collegamenti e migliorando il layout.<br /><br />I link inseriti nella categoria Main saranno visualizzati nel tuo menù di navigazione principale.";
$ns -> tablerender("Link Category Help", $text);
?>
