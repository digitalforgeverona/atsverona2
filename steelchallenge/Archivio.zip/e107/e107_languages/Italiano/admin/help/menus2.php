<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$caption = "Menu  Blocchi Help";
$text .= "Da qui puoi decidere 'Dove' e 'in quale ordine' visualizzare i tuoi Blocchi.
Usa le frecce per spostare in alto o in basso i Blocchi.<br />
I Blocchi nel Pannello centrale sono inattivi: puoi attivarli selezionando l'area in cui
vuoi posizionarli.";

$ns -> tablerender("Help Menù Blocchi", $text);
?>
