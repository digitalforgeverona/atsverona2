<?php
/*
------------------------------------------------------------------------
|     Italian Translation: e107 Italian Team  http:www.e107italia.org
------------------------------------------------------------------------
*/


$text = "Imposta da qui le tue preferenze per la chatbox.";

$ns -> tablerender("Chatbox", $text);
?>
