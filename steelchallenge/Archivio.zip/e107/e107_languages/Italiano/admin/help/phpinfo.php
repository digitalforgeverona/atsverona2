<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = " Questa pagina mostra tutte le impostazioni di configurazione PHP del tuo server. ";
$ns -> tablerender("Help Informazioni PHP", $text);
?>
