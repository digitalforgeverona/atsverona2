<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org

$text = "Gestione Temi ti consente di impostare sia il Tema 'predefinito' del sito che quello
per l'Area Amministrazione.";

$ns -> tablerender("Help Gestione Temi", $text);
?>
