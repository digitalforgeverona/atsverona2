<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Questa gamma di utilità ti permette di amministrare il tuo database.";
$ns -> tablerender("Utilità Database", $text);
?>
