<?php

//     Italian Translation:
//           e107 Italian Team http://www.e107it.org
//           con la collaborazione di Stefano Vecchi

$text = "Puoi suddividere le news in categorie divers, e permettere ai visitatori di visualizzare soltanto le news di quelle categories. <br /><br />Carica le icone/immagini per le news in ".e_THEME."-yourtheme-/images/ oppure in themes/shared/newsicons/.";
$ns -> tablerender("Help Categoria News", $text);
?>
