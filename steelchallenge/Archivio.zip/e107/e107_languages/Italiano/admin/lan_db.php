<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_db.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/10/31 21:16:29 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Backup delle Impostazione Core eseguito nel database.");
define("DBLAN_2", "Salvataggio backup database di e107");
define("DBLAN_3", "Backup SQL database");
define("DBLAN_4", "Verifica integrità del database di e107");
define("DBLAN_5", "Verifica");
define("DBLAN_6", "Ottimizza il database di e107");
define("DBLAN_7", "Optimizza il database SQL");
define("DBLAN_8", "Effettua il backup delle impostazioni del CORE");
define("DBLAN_9", "Backup CORE");
define("DBLAN_10", "Utilità Database");
define("DBLAN_11", "Database mySQL");
define("DBLAN_12", "ottimizzato");
define("DBLAN_13", "Indietro");
define("DBLAN_14", "Fatto");
define("DBLAN_15", "Verifica aggiornamenti del db disponibili");
define("DBLAN_16", "Verifica Aggiornamenti");

define("DBLAN_17", "Nome Pref.");
define("DBLAN_18", "Valore Pref.");
define("DBLAN_19", "Click per aprire l'editor delle preferenze (solo per utenti avanzati)");
define("DBLAN_20", "Editor Preferenze");
define("DBLAN_21", "Elimina selezionati");
define("DBLAN_22", "Plugin: vedi e analizza");
define("DBLAN_23", "Analisi Completa");
define("DBLAN_24", "Nome");
define("DBLAN_25", "Directory");
define("DBLAN_26", "Includi add-ons");
define("DBLAN_27", "Installato");
define("DBLAN_28", "Click per analizzare cambiamenti nelle directory dei plugin");
define("DBLAN_29", "Analizza le directory dei plugin");

// 7.8
define("DBLAN_30", " (Se un inserimento mostra un errore, controlla caratteri fuori della apertura/chiusura tags PHP)");
define("DBLAN_31", "OK");
define("DBLAN_32", "Errore");
define("DBLAN_33", "Non accessible");
define("DBLAN_34", "Non verificato");

?>
