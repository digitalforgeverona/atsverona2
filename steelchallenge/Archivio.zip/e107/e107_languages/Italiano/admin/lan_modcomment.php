<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_modcomment.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/30 14:18:21 $
|     $Author: lisa_ $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Modera.");
define("MDCLAN_2", "Nessun commento per questo articolo");
define("MDCLAN_3", "Utente");
define("MDCLAN_4", "Ospite");
define("MDCLAN_5", "sblocca");
define("MDCLAN_6", "blocca");
define("MDCLAN_8", "Modera Commenti");
define("MDCLAN_9", "Attenzione! Eliminando il commento principale saranno eliminate tutte le risposte!");
define("MDCLAN_10", "Opzioni");
define("MDCLAN_11", "Commento");
define("MDCLAN_12", "Commenti");
define("MDCLAN_13", "Bloccato");
define("MDCLAN_14", "Chiudi commenti");
define("MDCLAN_15", "Aperto");
define("MDCLAN_16", "Chiuso");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");
?>