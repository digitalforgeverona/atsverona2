<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_banlist.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/11/18 02:29:09 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

define("BANLAN_1", "Rimosso Ban.");
define("BANLAN_2", "Nessun ban.");
define("BANLAN_3", "Ban esistenti");
define("BANLAN_4", "Rimuovi ban");
define("BANLAN_5", "Inserisci IP, indirizzo email, oppure host");
define("BANLAN_7", "Motivo");
define("BANLAN_8", "Utenti Bannati");
define("BANLAN_9", "Banna Utenti dal sito");
define("BANLAN_10", "IP / Email / Motivo");
define("BANLAN_11", "Auto-ban: più di 10 tentativi di login falliti");
define("BANLAN_12", "Nota: Il Reverse DNS è attualmente disabilitato, deve essere abilitato per permettere il ban da host.  Bannando da IP e email la funzionalità ritornerà normale.");
define("BANLAN_13", "Nota: Per bannare un Utente per Username, vai alla pagina di amministrazione Utenti: ");


?>
