<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_administrator.php,v $
|     $Revision: 1.12 $
|     $Date: 2005/09/09 20:32:06 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.0rg	
+----------------------------------------------------------------------------+
*/
define("ADMSLAN_0", "Nuovo amministratore creato per");
define("ADMSLAN_1", "ora ha lo status di amministratore.");
define("ADMSLAN_2", "aggiornato in database.");
define("ADMSLAN_3", "è l'amministratore principale del sito e non può essere editato.");
define("ADMSLAN_4", "Continua");
define("ADMSLAN_5", "Errore!");
define("ADMSLAN_6", "è l'amministratore principale e non può essere cancellato.");
define("ADMSLAN_13", "Amministrazione esistente");
define("ADMSLAN_16", "Nome Amministratore");
define("ADMSLAN_17", "Password Amministratore");
define("ADMSLAN_18", "Permessi");
define("ADMSLAN_19", "Cambio Preferenze Sito");
define("ADMSLAN_20", "Cambio Menù");
define("ADMSLAN_21", "Aggiunta Amministratore Sito");
define("ADMSLAN_22", "Moderazione Utenti/bans etc");
define("ADMSLAN_23", "Creazione/modifica Menu Pagine Personali");
define("ADMSLAN_24", "Gestione Categorie Download");
define("ADMSLAN_25", "Caricamento/Gestione files");
define("ADMSLAN_26", "Supervisore categorie news");
define("ADMSLAN_27", "Supervisore categorie links");
define("ADMSLAN_28", "Impostazione Manutenzione Sito");
define("ADMSLAN_29", "Gestione banners");
define("ADMSLAN_30", "Configurazione news feed headlines");
define("ADMSLAN_31", "Configurazione faccine");
define("ADMSLAN_32", "Configurazione contenuti Home Page");
define("ADMSLAN_33", "Configurazione log/statistiche");
define("ADMSLAN_34", "Configurazione meta tags");
define("ADMSLAN_35", "Configurazione caricamento file pubblici");
define("ADMSLAN_36", "Configura impostazioni immagini");
define("ADMSLAN_37", "Moderazione commenti");
define("ADMSLAN_39", "Inserimento news");
define("ADMSLAN_40", "Inserimento links");
define("ADMSLAN_41", "Inserimento articoli");
define("ADMSLAN_42", "Inserimento recensioni");
define("ADMSLAN_43", "Inserimento pagine di contenuti");
define("ADMSLAN_44", "Inserimento downloads");
define("ADMSLAN_45", "Inserimento sondaggi");
define("ADMSLAN_46", "Messaggio di benvenuto");
define("ADMSLAN_47", "Moderazione news inviate");
define("ADMSLAN_49", "Seleziona tutto");
define("ADMSLAN_51", "Deseleziona tutto");
define("ADMSLAN_52", "Aggiorna");
define("ADMSLAN_53", "Aggiungi amministratore");
define("ADMSLAN_54", "Amministratori Sito");
define("ADMSLAN_55", "Campi non completi");
define("ADMSLAN_56", "Amministratore Sito");
define("ADMSLAN_58", "Amministratore Principale Sito");
define("ADMSLAN_59", "Rimuovi Amministratore");
define("ADMSLAN_60", "Sei sicuro di rimuovere lo status di amministratore a");
define("ADMSLAN_61", "Amministratore Eliminato ");
define("ADMSLAN_62", "Gestione Plugin");
define("ADMSLAN_64", "Pulizia la cache");
define("ADMSLAN_65", "Configurazione impostazioni invio mail");
define("ADMSLAN_66", "Configurazione Modulo Ricerca");
define("ADMSLAN_67", "Scan con file inspector");
define("ADMSLAN_68", "Configurazione notifiche email");
define("ADMSLAN_69", "è già un Amministratore e deve essere pubblicato.");
define("ADMSLAN_70", "Torna alla lista Amministratori");
define("ADMSLAN_71", "Clicca qui per visualizzare privilegi");


?>