<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_footer.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/29 17:45:38 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Site");
define("FOOTLAN_2", "Head Admin");
define("FOOTLAN_3", "Version");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Admin Theme");
define("FOOTLAN_6", "by");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Install date");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "PHP Version");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Site Info");
define("FOOTLAN_14", "Show Docs");
define("FOOTLAN_15", "Documentation");
define("FOOTLAN_16", "Database");
define("FOOTLAN_17", "Charset");
define("FOOTLAN_18", "Site Theme");

?>